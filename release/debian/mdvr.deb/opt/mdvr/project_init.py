import subprocess
import sys
import os


def run_cmd(cmd, check=True):
    print(f"Виконую: {cmd}")
    result = subprocess.run(cmd, shell=True)
    if check and result.returncode != 0:
        print(f"Помилка виконання: {cmd}")
        sys.exit(result.returncode)


def main():
    # 1. Видалити python3-rpi.gpio
    run_cmd("apt remove -y python3-rpi.gpio")

    # 2. Встановити rpi-lgpio у віртуальне оточення
    venv_python = "/opt/mdvr/venv/bin/python"
    run_cmd(f"{venv_python} -m pip install --upgrade pip")
    run_cmd(f"{venv_python} -m pip install rpi-lgpio")

    # 3. Встановити nginx
    run_cmd("apt update")
    run_cmd("apt install -y nginx")

    # 3.1. Видалити файл default, якщо існує
    default_site = "/etc/nginx/sites-enabled/default"
    if os.path.exists(default_site):
        run_cmd(f"rm {default_site}")

    # 4. Перезапустити Network Manager
    run_cmd("systemctl restart NetworkManager")

    # 5. Ініціалізація systemd сервісів
    run_cmd("systemctl stop mdvr_rs.service")
    run_cmd("systemctl disable mdvr_rs.service")

    run_cmd("systemctl enable mdvr_space_check.timer")
    run_cmd("systemctl enable mdvr.service")
    run_cmd("systemctl enable mdvr_web.service")
    run_cmd("systemctl enable mdvr_upload.timer")
    run_cmd("systemctl enable mdvr_system_guard.timer")
    run_cmd("systemctl enable mdvr_vpn_check.timer")

    # Apply new venv
    run_cmd("systemctl daemon-reload")
    run_cmd("systemctl restart mdvr.service")
    run_cmd("systemctl restart mdvr_upload.timer")
    run_cmd("systemctl restart mdvr_web.service")
    run_cmd("systemctl restart mdvr_space_check.timer")
    run_cmd("systemctl restart mdvr_system_guard.timer")
    run_cmd("systemctl restart mdvr_vpn_check.timer")

    # Встановити часовий пояс
    run_cmd('timedatectl set-timezone "Europe/Kyiv"')
    run_cmd("systemctl daemon-reload")


if __name__ == "__main__":
    main()

