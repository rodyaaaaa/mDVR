#!/usr/bin/env python3
import time
from gpiozero import Button
import RPi.GPIO as GPIO

def test_gpio_pins():
    # Test GPIO pins 22 and 23 (BCM numbering)
    test_pins = [22, 23]
    
    print("Testing GPIO pins...")
    print("Press Ctrl+C to exit")
    
    # Set up buttons with pull-up resistors
    buttons = [Button(pin, pull_up=True, bounce_time=0.1) for pin in test_pins]
    
    def button_pressed(button):
        print(f"Button on pin {button.pin} pressed")
    
    # Assign callbacks
    for btn in buttons:
        btn.when_pressed = lambda b=btn: button_pressed(b)
    
    try:
        while True:
            print("-" * 30)
            print("Current button states:")
            for i, btn in enumerate(buttons):
                print(f"Pin {test_pins[i]}: {'PRESSED' if btn.is_pressed else 'released'}")
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nCleaning up...")
        for btn in buttons:
            btn.close()
        print("Done!")

if __name__ == "__main__":
    test_gpio_pins()
