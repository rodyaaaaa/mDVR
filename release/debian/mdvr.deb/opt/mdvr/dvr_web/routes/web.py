import json
import os
import subprocess
import shutil

from flask import Blueprint, jsonify, request, send_from_directory
from datetime import timedelta, datetime

from dvr_web.constants import VPN_CONFIG_PATH, MATERIALS_DIR

# Paths for preserving and restoring original WireGuard config
BACKUP_DIR = "/etc/mdvr"
ORIGINAL_VPN_BACKUP_PATH = os.path.join(BACKUP_DIR, "wg0.conf.original")
from dvr_web.utils import generate_nginx_configs, get_camera_ports, load_config, restart_mdvr_engine, update_imei, update_watchdog, get_config_path


web_bp = Blueprint('web', __name__)


@web_bp.route('/get-camera-ports')
def get_camera_ports_route():
    return jsonify(get_camera_ports())


@web_bp.route('/get-imei')
def get_imei():
    try:
        config = load_config()
        return jsonify({"imei": config['program_options']['imei']})
    except Exception as e:
        return jsonify({"imei": "", "error": str(e)})


@web_bp.route('/get-service-status/<service_name>')
def get_service_status(service_name):
    try:
        status = os.popen(f"systemctl is-active {service_name}").read().strip()
        enabled = os.popen(f"systemctl is-enabled {service_name}").read().strip()
        description = os.popen(f"systemctl show {service_name} --property=Description --value").read().strip()
        return jsonify({
            "status": status,
            "enabled": enabled == "enabled",
            "description": description
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ===== Logs browser (files under /etc/mdvr/logs) =====
LOGS_ROOT = "/etc/mdvr/logs"

def _safe_join_logs(*parts: str) -> str:
    """Safely join paths under LOGS_ROOT and ensure no escape is possible."""
    base = os.path.realpath(LOGS_ROOT)
    target = os.path.realpath(os.path.join(base, *parts))
    if not target.startswith(base + os.sep) and target != base:
        raise ValueError("Path escapes logs root")
    return target


@web_bp.route('/logs/list-services')
def logs_list_services():
    """List top-level services (directories) under /etc/mdvr/logs."""
    try:
        base = _safe_join_logs()
        if not os.path.isdir(base):
            return jsonify({"services": [], "message": f"Directory not found: {LOGS_ROOT}"})
        items = []
        for name in sorted(os.listdir(base)):
            p = os.path.join(base, name)
            if os.path.isdir(p):
                items.append(name)
        return jsonify({"services": items})
    except Exception as e:
        return jsonify({"services": [], "error": str(e)}), 500


@web_bp.route('/logs/list-files')
def logs_list_files():
    """List files for a given service directory.

    Query: service=<dir>
    """
    try:
        service = (request.args.get('service') or '').strip()
        if not service:
            return jsonify({"files": [], "error": "Missing 'service'"}), 400
        sdir = _safe_join_logs(service)
        if not os.path.isdir(sdir):
            return jsonify({"files": [], "message": f"Service not found: {service}"}), 404
        files = []
        for name in sorted(os.listdir(sdir)):
            fp = os.path.join(sdir, name)
            if os.path.isfile(fp):
                try:
                    st = os.stat(fp)
                    files.append({
                        "name": name,
                        "size": st.st_size,
                        "mtime": int(st.st_mtime)
                    })
                except Exception:
                    files.append({"name": name, "size": None, "mtime": None})
        return jsonify({"files": files})
    except Exception as e:
        return jsonify({"files": [], "error": str(e)}), 500


@web_bp.route('/logs/read')
def logs_read_file():
    """Read last lines of a log file.

    Query: service=<dir>&file=<filename>&limit=200&offset=0
    Returns lines with simple offset pagination from the end of file.
    """
    try:
        service = (request.args.get('service') or '').strip()
        fname = (request.args.get('file') or '').strip()
        limit = max(1, min(int(request.args.get('limit', 200)), 2000))
        offset = max(0, int(request.args.get('offset', 0)))

        if not service or not fname:
            return jsonify({"lines": [], "error": "Missing 'service' or 'file'"}), 400

        # Disallow path components in fname
        if os.path.sep in fname or (os.path.altsep and os.path.altsep in fname):
            return jsonify({"lines": [], "error": "Invalid file name"}), 400

        fp = _safe_join_logs(service, fname)
        if not os.path.isfile(fp):
            return jsonify({"lines": [], "message": "File not found"}), 404

        # Efficiently read last N lines with offset
        try:
            with open(fp, 'rb') as f:
                # Read entire file if small; else tail
                f.seek(0, os.SEEK_END)
                size = f.tell()
                block = 4096
                data = b''
                to_read = size
                # Read chunks from end until we have enough lines (limit+offset)
                needed = limit + offset
                lines_found = 0
                while to_read > 0 and lines_found <= needed:
                    read_size = block if to_read >= block else to_read
                    f.seek(to_read - read_size)
                    chunk = f.read(read_size)
                    data = chunk + data
                    lines_found = data.count(b'\n')
                    to_read -= read_size
                # Split and take from end
                all_lines = data.splitlines()
                end_idx = len(all_lines) - offset
                start_idx = max(0, end_idx - limit)
                page = all_lines[start_idx:end_idx]
                # Decode safely
                text_lines = [ln.decode('utf-8', errors='replace') for ln in page]
        except Exception:
            # Fallback simple read
            with open(fp, 'r', errors='replace') as f:
                raw = f.read().splitlines()
            end_idx = max(0, len(raw) - offset)
            start_idx = max(0, end_idx - limit)
            text_lines = raw[start_idx:end_idx]

        return jsonify({
            "service": service,
            "file": fname,
            "offset": offset,
            "limit": limit,
            "count": len(text_lines),
            "next_offset": offset + len(text_lines),
            "lines": text_lines
        })
    except Exception as e:
        return jsonify({"lines": [], "error": str(e)}), 500


@web_bp.route('/get-network-info')
def get_network_info():
    """Return network info: interfaces and IP addresses.
    Uses `ip -j addr` if available. Falls back to `hostname -I` on error.
    """
    try:
        # Try JSON output from iproute2
        raw = subprocess.check_output(["ip", "-j", "addr"], text=True)
        arr = json.loads(raw)
        interfaces = []
        for itf in arr:
            # Skip loopback interface
            if (itf.get('ifname') or '').lower() == 'lo':
                continue
            addrs = []
            for ai in itf.get('addr_info', []):
                addrs.append({
                    'family': ai.get('family'),
                    'local': ai.get('local'),
                    'prefixlen': ai.get('prefixlen'),
                    'scope': ai.get('scope')
                })
            interfaces.append({
                'name': itf.get('ifname'),
                'index': itf.get('ifindex'),
                'mtu': itf.get('mtu'),
                'state': itf.get('operstate'),
                'mac': itf.get('address'),
                'addresses': addrs
            })

        # Collect routing metrics per interface (from main table)
        route_metrics = {}
        default_metrics = {}
        try:
            routes_raw = subprocess.check_output(["ip", "-j", "route", "show", "table", "main"], text=True)
            routes = json.loads(routes_raw)
            for r in routes:
                dev = r.get('dev')
                if not dev:
                    continue
                metric = r.get('metric')
                if dev not in route_metrics:
                    route_metrics[dev] = set()
                if metric is not None:
                    route_metrics[dev].add(metric)
                # Capture default route metric(s) specifically
                dst = r.get('dst') or r.get('destination')
                if dst in (None, 'default', '0.0.0.0/0', '::/0'):
                    default_metrics.setdefault(dev, [])
                    if metric is not None:
                        default_metrics[dev].append(metric)
        except Exception:
            # Ignore routing errors; priorities will be absent
            pass

        # Enrich interfaces with priority/metrics
        for itf in interfaces:
            name = itf.get('name')
            metrics_list = sorted(route_metrics.get(name, [])) if name else []
            itf['route_metrics'] = metrics_list
            # Priority: prefer default route metric, else min of metrics_list
            dms = default_metrics.get(name, []) if name else []
            if dms:
                itf['priority'] = min(dms)
            elif metrics_list:
                itf['priority'] = metrics_list[0]
            else:
                itf['priority'] = None

        # Quick summary of IPv4 addresses
        ipv4_list = []
        for itf in interfaces:
            for a in itf['addresses']:
                if a.get('family') == 'inet' and a.get('local'):
                    ipv4_list.append(a['local'])

        return jsonify({
            'interfaces': interfaces,
            'ipv4': ipv4_list
        })
    except Exception as e:
        try:
            ips = subprocess.check_output(["hostname", "-I"], text=True).strip()
        except Exception:
            ips = ""
        return jsonify({
            'interfaces': [],
            'ipv4': [ip for ip in ips.split() if ip],
            'error': str(e)
        })


@web_bp.route('/get-iptables-rules')
def get_iptables_rules():
    """Return only raw filter rules from iptables (-S)."""
    try:
        output = subprocess.check_output(["iptables", "-S"], text=True, stderr=subprocess.STDOUT)
        return jsonify({
            "filter_rules": output.splitlines()
        })
    except subprocess.CalledProcessError as e:
        return jsonify({
            "filter_rules": [],
            "error": e.output.strip() or str(e)
        }), 500
    except Exception as e:
        return jsonify({
            "filter_rules": [],
            "error": str(e)
        }), 500


@web_bp.route('/reboot', methods=['POST'])
def reboot_device():
    """Initiate a system reboot.

    Returns JSON {"success": true} on success. The web UI will soon become unavailable.
    """
    try:
        # Use reboot command; assumes the service has sufficient privileges.
        subprocess.Popen(['reboot'])
        return jsonify({"success": True, "message": "Reboot initiated"})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@web_bp.route('/about-info')
def get_about_info():
    """Collect basic hardware and application package info for the About tab."""
    info = {
        "hardware": {},
        "program": {}
    }
    try:
        # Hardware: Model
        model = None
        try:
            # Common on SBCs
            paths = [
                "/sys/firmware/devicetree/base/model",
                "/proc/device-tree/model"
            ]
            for p in paths:
                if os.path.exists(p):
                    with open(p, 'r', errors='ignore') as f:
                        model = f.read().strip('\x00').strip()
                        if model:
                            break
        except Exception:
            pass

        # Hardware: CPU model
        cpu_model = None
        try:
            with open('/proc/cpuinfo', 'r', errors='ignore') as f:
                for line in f:
                    if ':' in line:
                        key, val = [s.strip() for s in line.split(':', 1)]
                        if key in ('model name', 'Hardware', 'Processor'):
                            cpu_model = val
                            break
        except Exception:
            pass

        # Hardware: Memory total (kB)
        mem_total_kb = None
        try:
            with open('/proc/meminfo', 'r', errors='ignore') as f:
                for line in f:
                    if line.startswith('MemTotal:'):
                        parts = line.split()
                        if len(parts) >= 2 and parts[1].isdigit():
                            mem_total_kb = int(parts[1])
                        break
        except Exception:
            pass

        # Hardware: Kernel and Arch
        try:
            uname_r = subprocess.check_output(["uname", "-r"], text=True).strip()
        except Exception:
            uname_r = ""
        try:
            uname_m = subprocess.check_output(["uname", "-m"], text=True).strip()
        except Exception:
            uname_m = ""

        # Disk (root filesystem)
        disk = {}
        try:
            df_out = subprocess.check_output(["df", "-k", "/"], text=True).splitlines()
            if len(df_out) >= 2:
                # Filesystem 1K-blocks Used Available Use% Mounted on
                cols = df_out[1].split()
                if len(cols) >= 6:
                    total_kb = int(cols[1])
                    used_kb = int(cols[2])
                    avail_kb = int(cols[3])
                    disk = {
                        "total_kb": total_kb,
                        "used_kb": used_kb,
                        "avail_kb": avail_kb,
                        "use": cols[4],
                        "mount": cols[5]
                    }
        except Exception:
            pass

        info["hardware"] = {
            "model": model,
            "cpu_model": cpu_model,
            "mem_total_kb": mem_total_kb,
            "kernel": uname_r,
            "arch": uname_m,
            "disk_root": disk,
        }

        # Storage and filesystem info for materials directory
        storage = {}
        try:
            # Resolve mount source, fstype, and mountpoint for MATERIALS_DIR
            fm = subprocess.check_output([
                "findmnt", "-no", "SOURCE,FSTYPE,TARGET", "-T", MATERIALS_DIR
            ], text=True).strip()
            src = fstype = mnt = None
            if fm:
                parts = fm.split()
                if len(parts) >= 3:
                    src, fstype, mnt = parts[0], parts[1], parts[2]
                elif len(parts) == 2:
                    src, fstype = parts[0], parts[1]
            if not src or not fstype:
                # Fallback using df -P -T <path>
                try:
                    dfp = subprocess.check_output(["df", "-P", "-T", MATERIALS_DIR], text=True).splitlines()
                    if len(dfp) >= 2:
                        cols = dfp[1].split()
                        if len(cols) >= 7:
                            # Filesystem Type 1K-blocks Used Available Use% Mounted on
                            src = cols[0]
                            fstype = cols[1]
                            mnt = cols[-1]
                except Exception:
                    pass

            dev = src or ""
            storage.update({
                "path": MATERIALS_DIR,
                "mount_source": dev,
                "fstype": fstype,
                "mount_point": mnt,
            })

            # Determine base disk device and attributes (rotational, model, type)
            base = None
            if dev.startswith('/dev/'):
                devnode = dev
                try:
                    # Get parent kernel name (base disk), e.g., sda for sda1, nvme0n1 for nvme0n1p1
                    pk = subprocess.check_output(["lsblk", "-no", "PKNAME", devnode], text=True).strip()
                    base = pk if pk else devnode.replace('/dev/', '')
                except Exception:
                    base = devnode.replace('/dev/', '')

            # Read rotational flag
            rotational = None
            if base:
                rot_path = f"/sys/block/{base}/queue/rotational"
                try:
                    with open(rot_path, 'r') as f:
                        rotational = f.read().strip() == '1'
                except Exception:
                    rotational = None

            # Query lsblk for model and type
            model = None
            dtype = None
            try:
                if base:
                    model = subprocess.check_output(["lsblk", "-no", "MODEL", f"/dev/{base}"], text=True).strip() or None
                    dtype = subprocess.check_output(["lsblk", "-no", "TYPE", f"/dev/{base}"], text=True).strip() or None
            except Exception:
                pass

            storage.update({
                "device_base": (f"/dev/{base}" if base else None),
                "device_model": model,
                "device_type": dtype,  # e.g., disk
                "device_rotational": rotational,  # True for HDD, False for SSD/flash, None unknown
            })

        except Exception:
            # Ignore storage detection errors
            pass

        info["hardware"]["storage_materials"] = storage

        # Program/package info: mdvr deb package (and optional mdvr-web)
        def read_dpkg_status(pkg: str):
            try:
                out = subprocess.check_output(["dpkg", "-s", pkg], text=True, stderr=subprocess.STDOUT)
            except subprocess.CalledProcessError:
                return None
            data = {}
            for line in out.splitlines():
                if ':' in line:
                    k, v = line.split(':', 1)
                    data[k.strip()] = v.strip()
            return {
                "package": data.get("Package", pkg),
                "status": data.get("Status"),
                "version": data.get("Version"),
                "architecture": data.get("Architecture"),
                "maintainer": data.get("Maintainer"),
                "installed_size": data.get("Installed-Size"),
                "description": data.get("Description"),
            }

        program = {}
        for candidate in ("mdvr", "mdvr-web", "mdvr_web"):
            pkg_info = read_dpkg_status(candidate)
            if pkg_info:
                program[candidate] = pkg_info

        info["program"] = program

        return jsonify(info)
    except Exception as e:
        return jsonify({"error": str(e), **info}), 500


@web_bp.route('/get-service-logs/<service_name>')
def get_service_logs(service_name):
    """
    Return recent logs for a systemd unit using a simple offset-based pagination.
    Query params:
      - limit: number of lines to return (default 200, max 1000)
      - offset: how many most-recent lines to skip (default 0)
    """
    try:
        limit = int(request.args.get('limit', 200))
        offset = int(request.args.get('offset', 0))
        limit = max(1, min(limit, 1000))
        offset = max(0, offset)

        # Fetch offset+limit most recent lines, then slice the last `limit` lines
        total = offset + limit
        cmd = f"journalctl -u {service_name} -n {total} --no-pager -o short-iso"
        raw = os.popen(cmd).read()
        lines = [ln for ln in raw.splitlines() if ln.strip()]
        # Take the slice from the end accounting for offset and limit
        total_len = len(lines)
        end_idx = max(0, total_len - offset)
        start_idx = max(0, end_idx - limit)
        page = lines[start_idx:end_idx]

        return jsonify({
            "unit": service_name,
            "offset": offset,
            "limit": limit,
            "count": len(page),
            "next_offset": offset + len(page),
            "logs": page
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@web_bp.route('/save-write-mode', methods=['POST'])
def save_write_mode():
    data = request.get_json()
    try:
        config = load_config()
        config['program_options']['photo_mode'] = 0 if data.get('write_mode') == 'video' else 1

        with open(get_config_path(), 'w') as file:
            json.dump(config, file, indent=4)

        restart_mdvr_engine()

        return jsonify({"success": True, "message": "Write mode updated"})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@web_bp.route('/save-rs-timeout', methods=['POST'])
def save_rs_timeout():
    data = request.get_json()
    try:
        value = data.get('rs_timeout', 0)
        config = load_config()
        print(config["reed_switch"]["rs_timeout"])
        config["reed_switch"]["rs_timeout"] = value
        with open(get_config_path(), 'w') as file:
            json.dump(config, file, indent=4)
        return jsonify({"success": True, "message": "RS Timeout saved"})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@web_bp.route('/save-ftp-config', methods=['POST'])
def save_ftp_config():
    data = request.get_json()
    print(f"[DEBUG FTP] Received FTP config data: {data}")
    try:
        config = load_config()
        print(f"[DEBUG FTP] Loaded config: {config}")

        ftp_data = data.get('ftp', {})
        print(f"[DEBUG FTP] FTP data to save: {ftp_data}")
        config['ftp'] = {
            "server": ftp_data.get('server', ''),
            "port": ftp_data.get('port', 21),
            "user": ftp_data.get('user', ''),
            "password": ftp_data.get('password', ''),
            "car_name": ftp_data.get('car_name', '')
        }
        
        config_path = get_config_path()
        print(f"[DEBUG FTP] Saving to: {config_path}")
        print(f"[DEBUG FTP] Updated config: {config}")

        with open(config_path, 'w') as file:
            json.dump(config, file, indent=4)
        
        print(f"[DEBUG FTP] Config file saved successfully")
        update_imei()

        return jsonify({"success": True, "message": "FTP settings saved!"})
    except Exception as e:
        print(f"[DEBUG FTP] Error saving FTP config: {str(e)}")
        return jsonify({"success": False, "error": f"Error: {str(e)}"}), 500


@web_bp.route('/set-upload-enabled', methods=['POST'])
def set_upload_enabled():
    """Enable/disable mdvr_upload.timer and start/stop it accordingly.
    Request JSON: {"enabled": true|false}
    Response JSON: {"success": bool, "enabled": bool, "status": "active"|"inactive"|..., "error"?: str}
    """
    try:
        data = request.get_json(silent=True) or {}
        target_enabled = bool(data.get('enabled'))

        if target_enabled:
            os.system("systemctl enable mdvr_upload.timer")
            os.system("systemctl start mdvr_upload.timer")
        else:
            os.system("systemctl stop mdvr_upload.timer")
            os.system("systemctl disable mdvr_upload.timer")

        status = os.popen("systemctl is-active mdvr_upload.timer").read().strip()
        enabled = os.popen("systemctl is-enabled mdvr_upload.timer").read().strip() == "enabled"
        return jsonify({
            "success": True,
            "enabled": enabled,
            "status": status
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@web_bp.route('/set-vpn-enabled', methods=['POST'])
def set_vpn_enabled():
    """Enable/disable WireGuard service wg-quick@wg0 and start/stop accordingly.
    Request JSON: {"enabled": true|false}
    Response JSON: {"success": bool, "enabled": bool, "status": str}
    """
    try:
        data = request.get_json(silent=True) or {}
        target_enabled = bool(data.get('enabled'))

        unit = 'wg-quick@wg0.service'
        unit_base = 'wg-quick@wg0'

        if target_enabled:
            os.system(f"systemctl enable {unit_base}")
            os.system(f"systemctl start {unit_base}")
        else:
            os.system(f"systemctl stop {unit_base}")
            os.system(f"systemctl disable {unit_base}")

        status = os.popen(f"systemctl is-active {unit}").read().strip()
        enabled = os.popen(f"systemctl is-enabled {unit}").read().strip() == "enabled"
        return jsonify({
            "success": True,
            "enabled": enabled,
            "status": status
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@web_bp.route('/save-video-options', methods=['POST'])
def save_video_options():
    data = request.get_json()
    try:
        config = load_config()

        # Make sure size_folder_limit_gb is an integer with a default value
        try:
            config['program_options']['size_folder_limit_gb'] = int(data.get('size_folder_limit_gb', 10))
        except (TypeError, ValueError):
            config['program_options']['size_folder_limit_gb'] = 10

        config['rtsp_options'] = {
            "rtsp_transport": data.get('rtsp_transport', 'tcp'),
            "rtsp_resolution_x": data.get('rtsp_resolution_x', 640),
            "rtsp_resolution_y": data.get('rtsp_resolution_y', 480)
        }

        video_duration = data.get('video_duration')
        if video_duration:
            video_duration = video_duration.strip().lower()
            cleaned_duration = ''.join([c for c in video_duration if c.isdigit() or c == ':'])
            if ':' in cleaned_duration:
                parts = cleaned_duration.split(':')
                if len(parts) != 3:
                    raise ValueError("Incorrect format. Use HH:MM:SS or minutes (e.g., '10 min').")
                h, m, s = map(int, parts)
            else:
                try:
                    minutes = int(cleaned_duration)
                    h = minutes // 60
                    m = minutes % 60
                    s = 0
                except ValueError:
                    raise ValueError("Incorrect format for minutes. For example: '10' or '10 min'.")

            if m > 59 or s > 59:
                raise ValueError("Invalid minutes/seconds values (must be ≤ 59).")

            formatted_duration = f"{h:02d}:{m:02d}:{s:02d}"
            config['video_options']['video_duration'] = formatted_duration
            
            # Make sure fps is an integer with a default value
            try:
                config['video_options']['fps'] = int(data.get('fps', 15))
            except (TypeError, ValueError):
                config['video_options']['fps'] = 15

            seconds = timedelta(hours=h, minutes=m, seconds=s).total_seconds()
            update_watchdog(int(seconds * 10))

        photo_timeout = data.get('photo_timeout')

        if photo_timeout:
            try:
                config['photo_timeout'] = int(photo_timeout)
                update_watchdog(int(int(photo_timeout) * 5))
            except (TypeError, ValueError):
                config['photo_timeout'] = 10
                update_watchdog(50)  # Default 10 * 5

        with open(get_config_path(), 'w') as file:
            json.dump(config, file, indent=4)

        restart_mdvr_engine()

        return jsonify({"success": True, "message": "Settings saved!"})

    except ValueError as ve:
        return jsonify({"success": False, "error": str(ve)}), 400
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@web_bp.route('/save-vpn-config', methods=['POST'])
def save_vpn_config():
    data = request.get_json()
    if not data or 'vpn_config' not in data:
        return jsonify({"success": False, "error": "No config data received"}), 400

    try:
        with open(VPN_CONFIG_PATH, 'w') as file:
            file.write(data['vpn_config'])

        # Only save configuration. Service control is managed by the VPN toggle.
        update_imei()

        return jsonify({"success": True, "message": "VPN config saved successfully"})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@web_bp.route('/get-vpn-config')
def get_vpn_config():
    try:
        if not os.path.exists(VPN_CONFIG_PATH):
            return jsonify({"config": "", "error": f"Config not found: {VPN_CONFIG_PATH}"}), 404
        with open(VPN_CONFIG_PATH, 'r') as f:
            content = f.read()
        return jsonify({"config": content})
    except Exception as e:
        return jsonify({"config": "", "error": str(e)}), 500


@web_bp.route('/delete-vpn-config', methods=['POST'])
def delete_vpn_config():
    """Backup and clear the WireGuard config file contents."""
    try:
        if not os.path.exists(VPN_CONFIG_PATH):
            return jsonify({"success": True, "message": "Config not present"})

        # Backup existing config
        try:
            shutil.copy2(VPN_CONFIG_PATH, VPN_CONFIG_PATH + '.bak')
        except Exception:
            pass

        # Truncate file atomically
        tmp_path = VPN_CONFIG_PATH + '.tmp'
        with open(tmp_path, 'w') as f:
            f.write('')
        os.replace(tmp_path, VPN_CONFIG_PATH)

        return jsonify({"success": True, "message": "VPN config deleted"})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@web_bp.route('/apply-vpn-non-priority', methods=['POST'])
def apply_vpn_non_priority():
    """
    Make WireGuard VPN non-priority by:
      1) Removing DNS line(s) from [Interface]
      2) Ensuring 'Table = off' in [Interface]
      3) Ensuring 'PersistentKeepAlive = 25' in each [Peer]
      4) Restarting wg-quick@wg0 if it's enabled
    """
    try:
        # Read existing config
        if not os.path.exists(VPN_CONFIG_PATH):
            return jsonify({"success": False, "error": f"Config not found: {VPN_CONFIG_PATH}"}), 404

        with open(VPN_CONFIG_PATH, 'r') as f:
            lines = f.readlines()

        new_lines = []
        section = None  # 'interface' | 'peer' | None
        interface_table_present = False
        peer_keepalive_present = False

        def flush_section_footer(next_header=False):
            nonlocal section, interface_table_present, peer_keepalive_present, new_lines
            if section == 'interface' and not interface_table_present:
                new_lines.append('Table = off\n')
            if section == 'peer' and not peer_keepalive_present:
                new_lines.append('PersistentKeepAlive = 25\n')
            if next_header:
                # Reset flags when a new section header is about to be processed
                if section == 'interface':
                    interface_table_present = False
                if section == 'peer':
                    peer_keepalive_present = False
            section = None

        for raw in lines:
            line = raw
            stripped = line.strip()

            # Detect section headers
            if stripped.startswith('[') and stripped.endswith(']'):
                # Flush any missing required keys before starting the next section
                flush_section_footer(next_header=True)
                header = stripped.lower()
                if header == '[interface]':
                    section = 'interface'
                elif header == '[peer]':
                    section = 'peer'
                else:
                    section = None
                new_lines.append(line)
                continue

            # Process key-value lines based on current section
            if section == 'interface':
                # Skip DNS lines
                if stripped.lower().startswith('dns'):
                    continue
                # Normalize/ensure Table = off
                if stripped.lower().startswith('table'):
                    new_lines.append('Table = off\n')
                    interface_table_present = True
                    continue

            if section == 'peer':
                # Normalize/ensure PersistentKeepAlive = 25
                if stripped.lower().startswith('persistentkeepalive'):
                    new_lines.append('PersistentKeepAlive = 25\n')
                    peer_keepalive_present = True
                    continue

            # Default: keep line as-is
            new_lines.append(line)

        # End of file: flush for the last open section
        if section is not None:
            flush_section_footer(next_header=False)

        # Ensure a one-time backup of the original config in /etc/mdvr/ for restore
        try:
            os.makedirs(BACKUP_DIR, exist_ok=True)
            if not os.path.exists(ORIGINAL_VPN_BACKUP_PATH):
                shutil.copy2(VPN_CONFIG_PATH, ORIGINAL_VPN_BACKUP_PATH)
        except Exception:
            # Best-effort backup; ignore backup errors
            pass

        # Backup current config alongside for safety
        try:
            shutil.copy2(VPN_CONFIG_PATH, VPN_CONFIG_PATH + '.bak')
        except Exception:
            # Best-effort backup; ignore backup errors
            pass

        # Write updated config atomically
        tmp_path = VPN_CONFIG_PATH + '.tmp'
        with open(tmp_path, 'w') as f:
            f.writelines(new_lines)
        os.replace(tmp_path, VPN_CONFIG_PATH)

        # Restart wg-quick@wg0 if enabled
        unit = 'wg-quick@wg0'
        enabled_state = os.popen(f"systemctl is-enabled {unit}").read().strip()
        if enabled_state == 'enabled':
            os.system(f"systemctl restart {unit}")

        return jsonify({
            "success": True,
            "message": "Applied non-priority VPN settings",
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@web_bp.route('/apply-vpn-priority', methods=['POST'])
def apply_vpn_priority():
    """
    Restore the original WireGuard config from /etc/mdvr/wg0.conf.original,
    effectively making VPN priority again. Restarts wg-quick@wg0 if enabled.
    """
    try:
        if not os.path.exists(ORIGINAL_VPN_BACKUP_PATH):
            return jsonify({
                "success": False,
                "error": f"Original backup not found: {ORIGINAL_VPN_BACKUP_PATH}"
            }), 404

        # Best-effort backup of current config
        try:
            if os.path.exists(VPN_CONFIG_PATH):
                shutil.copy2(VPN_CONFIG_PATH, VPN_CONFIG_PATH + '.bak')
        except Exception:
            pass

        # Restore original config atomically
        tmp_path = VPN_CONFIG_PATH + '.tmp'
        with open(ORIGINAL_VPN_BACKUP_PATH, 'r') as src, open(tmp_path, 'w') as dst:
            dst.write(src.read())
        os.replace(tmp_path, VPN_CONFIG_PATH)

        # Restart wg-quick@wg0 if enabled
        unit = 'wg-quick@wg0'
        enabled_state = os.popen(f"systemctl is-enabled {unit}").read().strip()
        if enabled_state == 'enabled':
            os.system(f"systemctl restart {unit}")

        return jsonify({
            "success": True,
            "message": "Restored original VPN config (priority mode)",
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@web_bp.route('/save-video-links', methods=['POST'])
def save_video_links():
    data = request.get_json()
    try:
        config = load_config()
        camera_list = data.get('camera_list', [])
        config['camera_list'] = camera_list

        with open(get_config_path(), 'w') as file:
            json.dump(config, file, indent=4)

        if not generate_nginx_configs(camera_list):
            raise Exception("Failed to generate Nginx configs")

        restart_mdvr_engine()

        return jsonify({"success": True, "message": "Video links saved successfully"})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


# Materials endpoints
@web_bp.route('/materials/list')
def list_materials():
    try:
        if not os.path.isdir(MATERIALS_DIR):
            return jsonify({"files": [], "message": f"Directory not found: {MATERIALS_DIR}"})

        # Parse optional date filters
        def parse_date(d: str | None):
            if not d:
                return None
            d = d.strip()
            for fmt in ("%Y-%m-%d", "%d.%m.%Y"):
                try:
                    return datetime.strptime(d, fmt)
                except ValueError:
                    continue
            return None

        date_from_raw = request.args.get('date_from')
        date_to_raw = request.args.get('date_to')
        date_from = parse_date(date_from_raw)
        date_to = parse_date(date_to_raw)
        if date_from:
            # start of day
            date_from = datetime(year=date_from.year, month=date_from.month, day=date_from.day, hour=0, minute=0, second=0)
        if date_to:
            # end of day
            date_to = datetime(year=date_to.year, month=date_to.month, day=date_to.day, hour=23, minute=59, second=59)

        video_exts = {'.mp4', '.mkv', '.avi', '.mov', '.m3u8', '.ts'}
        items = []
        for name in sorted(os.listdir(MATERIALS_DIR)):
            path = os.path.join(MATERIALS_DIR, name)
            if not os.path.isfile(path):
                continue
            ext = os.path.splitext(name)[1].lower()
            if ext not in video_exts:
                continue
            stat = os.stat(path)

            # Parse filename according to dvr_video convention: c + '24' + yymmdd + [hhmmss]
            base = os.path.splitext(name)[0]
            display_name = name
            cam = None
            date_str = None
            time_str = None
            recorded_dt = None
            try:
                if len(base) >= 9 and base[1:3] == '24':
                    cam = int(base[0])
                    yymmdd = base[3:9]
                    # Convert to DD.MM.YYYY
                    yy = int(yymmdd[0:2])
                    mm = int(yymmdd[2:4])
                    dd = int(yymmdd[4:6])
                    yyyy = 2000 + yy
                    date_str = f"{dd:02d}.{mm:02d}.{yyyy}"
                    if len(base) >= 15:
                        hh = int(base[9:11])
                        mi = int(base[11:13])
                        ss = int(base[13:15])
                        time_str = f"{hh:02d}:{mi:02d}:{ss:02d}"
                        recorded_dt = datetime(year=yyyy, month=mm, day=dd, hour=hh, minute=mi, second=ss)
                    else:
                        recorded_dt = datetime(year=yyyy, month=mm, day=dd, hour=0, minute=0, second=0)
                    if cam and date_str:
                        display_name = f"Камера {cam} — {date_str}" + (f" {time_str}" if time_str else "")
            except Exception:
                # Fallback to original name on any parsing error
                pass

            if recorded_dt is None:
                recorded_dt = datetime.fromtimestamp(int(stat.st_mtime))

            # Apply filters
            if date_from and recorded_dt < date_from:
                continue
            if date_to and recorded_dt > date_to:
                continue

            items.append({
                "name": name,
                "size": stat.st_size,
                "mtime": int(stat.st_mtime),
                "url": f"/materials/file/{name}",
                "display_name": display_name,
                "camera": cam,
                "recorded_date": date_str,
                "recorded_time": time_str,
                "recorded_ts": int(recorded_dt.timestamp())
            })
        return jsonify({"files": items})
    except Exception as e:
        return jsonify({"files": [], "error": str(e)}), 500


@web_bp.route('/materials/file/<path:filename>')
def get_material_file(filename):
    # Serve file directly from materials directory
    return send_from_directory(MATERIALS_DIR, filename, as_attachment=False)
