import RPi.GPIO as GPIO
from gpiozero import Button
from threading import Lock
from time import time

class BaseGpio:
    def setup(self):
        raise NotImplementedError
    
    def pressed(self):
        raise NotImplementedError


class ImpulseRS(BaseGpio):
    def __init__(self, pin_a, pin_b):
        self.pin_a = pin_a
        self.pin_b = pin_b
        self.state = None
        self.last_change_time = 0
        self.debounce_time = 0.1  # 100ms debounce time
        self.lock = Lock()
        self.button_a = None
        self.button_b = None
        self.initialized = False

    def setup(self):
        if self.initialized:
            print("[DEBUG] Reed switch already initialized")
            return
            
        try:
            print(f"[DEBUG] Setting up GPIO pins - A:{self.pin_a}, B:{self.pin_b}")
            
            # Initialize buttons with pull-up resistors and debounce
            print("[DEBUG] Initializing button A...")
            self.button_a = Button(self.pin_a, pull_up=True, bounce_time=0.001)
            print("[DEBUG] Initializing button B...")
            self.button_b = Button(self.pin_b, pull_up=True, bounce_time=0.001)
            
            # Set up callbacks
            print("[DEBUG] Setting up button callbacks...")
            self.button_a.when_pressed = self._on_button_a
            self.button_b.when_pressed = self._on_button_b
            
            # Test initial button states
            print(f"[DEBUG] Initial button states - A: {self.button_a.is_pressed}, B: {self.button_b.is_pressed}")
            
            self.initialized = True
            print(f"[DEBUG] Successfully initialized impulse reed switch on pins A:{self.pin_a}, B:{self.pin_b}")
            
            # Add a test event to verify callbacks are working
            print("[DEBUG] Testing button callbacks...")
            self._on_button_a()
            self._on_button_b()
            
        except Exception as e:
            print(f"[ERROR] Failed to initialize impulse reed switch: {str(e)}")
            import traceback
            traceback.print_exc()
            self.initialized = False

    def _on_button_a(self):
        try:
            current_time = time()
            with self.lock:
                print(f"[DEBUG] Button A pressed - Current state: {self.state}, Last change: {current_time - self.last_change_time:.3f}s ago")
                if current_time - self.last_change_time > self.debounce_time:
                    self.state = True
                    self.last_change_time = current_time
                    print(f"[DEBUG] Button A - New state: {self.state} (Debounce passed)")
                else:
                    print(f"[DEBUG] Button A - Ignored (Debounce time not passed)")
        except Exception as e:
            print(f"[ERROR] Error in _on_button_a: {str(e)}")

    def _on_button_b(self):
        try:
            current_time = time()
            with self.lock:
                print(f"[DEBUG] Button B pressed - Current state: {self.state}, Last change: {current_time - self.last_change_time:.3f}s ago")
                if current_time - self.last_change_time > self.debounce_time:
                    self.state = False
                    self.last_change_time = current_time
                    print(f"[DEBUG] Button B - New state: {self.state} (Debounce passed)")
                else:
                    print(f"[DEBUG] Button B - Ignored (Debounce time not passed)")
        except Exception as e:
            print(f"[ERROR] Error in _on_button_b: {str(e)}")

    def pressed(self):
        if not self.initialized:
            self.setup()
            return None
            
        with self.lock:
            return self.state


class RSFactory:
    @staticmethod
    def create(impulse=True, **kwargs):
        if impulse:
            return ImpulseRS(**kwargs)
        else:
            raise NotImplementedError("Non-impulse mode not implemented")
