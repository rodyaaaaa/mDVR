// Функція для відкриття діалогового вікна підтвердження
function openConfirmDialog(message) {
    const dialog = document.querySelector('.confirm-dialog');
    const messageElement = dialog.querySelector('.confirm-dialog-message');
    messageElement.textContent = message;
    dialog.style.display = 'flex';
}

// Функція для закриття діалогового вікна підтвердження
function closeConfirmDialog() {
    const dialog = document.querySelector('.confirm-dialog');
    dialog.style.display = 'none';
}

// Функція для виконання тесту геркона
function executeReedSwitchTest() {
    closeConfirmDialog();
    fetch('/api/test/reed-switch', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Тест геркона успішно виконано');
        } else {
            alert('Помилка при виконанні тесту: ' + data.error);
        }
    })
    .catch(error => {
        alert('Помилка при виконанні тесту: ' + error);
    });
}

// Функції для роботи з діалоговим вікном підтвердження
function showConfirmDialog() {
    const dialog = document.getElementById('confirmDialog');
    dialog.style.display = 'flex';
}

function closeConfirmDialog() {
    const dialog = document.getElementById('confirmDialog');
    dialog.style.display = 'none';
}

function executeReedSwitchTest(action) {
    if (action === 'confirm') {
        // Тут буде код для виконання тесту геркона
        console.log('Тест геркона підтверджено');
    }
    closeConfirmDialog();
} 