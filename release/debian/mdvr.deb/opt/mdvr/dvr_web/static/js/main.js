// Main JavaScript file that imports all modules

// This is the main entry point for all JavaScript functionality
document.addEventListener('DOMContentLoaded', () => {
    console.log('mDVR Web Interface loaded');
}); 